let express = require('express')

let app = express()

app.get('/', (req, res) => {
res.send('Primeira rota com express')
})

app.get('/salgados', (req, res) => {
    console.log('tao com fome')
    res.send('Salgados da cantina')
    })

app.listen(8000, () => {
    console.log('A API esta funcionando na porta 8000')
})