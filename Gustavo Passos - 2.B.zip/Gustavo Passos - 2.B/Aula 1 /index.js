const { error } = require('console');
let { readFile, writeFile } = require('fs')

writeFile("arquivo.txt", "3 Periodo Sitema UniaALfa", (error) => {
    if (error) {
        throw error
    } else {
       console.log('Salvo com sucesso!!!!')
    }
}
)

readFile("arquivo.txt", "utf8", (error, texto) => {
    if (error) {
        throw error;
    } else {
        console.log(texto)
    }
})