const express = require('express')

const router = express.Router()

router.get('/', (requisicao, resposta) => {
    resposta.send('esta rodando com nodemon')
})
router.post('/teste', (requisicao, resposta) => {
    resposta.send('teste Nodemon REQ')
})

module.exports = router