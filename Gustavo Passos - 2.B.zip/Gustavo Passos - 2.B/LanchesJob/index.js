const express = require('express')

const PORT = 3001

const app = express()

app.use('/jobs', require('./routes/jobs'))

app.post('/teste', (requisicao, resposta) => {
    resposta.send('teste Nodemon REQ')
})

app.listen(PORT, () => {
    console.log('Express esta rodando na porta: ' + PORT)
})